#!/bin/bash

zip mk306262.zip Makefile *.cpp *.c *.h *.sh *.py exported_tests
